extern unsigned long long rand64 (void);
